// console.log('Bai tap 1')
// //a,
// console.log('Hello World')
// //b,
// console.log('Van Canh')
// //c,
// console.clear()
// //d,
// console.log('*****')
// console.log('*****')
// console.log('*****')
// console.log('*****')
// console.log('*****')
// //e,
// console.log('    *')
// console.log('   ***')
// console.log('  *****')
// console.log(' *******')
// console.log('*********')
// //f,
// console.log('   **       **')
// console.log('*       *       *')
// console.log('*               *')
// console.log('  *           *')
// console.log('     *     *')
// console.log('        *')
// console.log('bai tap 2')
// //a,
// var a=10
// console.log(a)

// //b,
// var b='10'
// console.log(b)
// //c,
// a=20
// console.log(a)
// //d,
// var pi=3.14
// console.log(pi)
// //e,
// pi=3.5
// console.log(pi)
// //f,l
// var dienThoai = {
//     ten: "iPhone 14",
//     hangSanXuat: "Apple",
//     mausac: "Trang",
//     gia: "1000USD"
// }
// console.log("Tên điện thoại:", dienThoai.ten)
// console.log("Hãng sản xuất:", dienThoai.hangSanXuat)
// console.log("Màu sắc:", dienThoai.mausac)
// console.log("Giá:", dienThoai.gia)
// console.log(dienThoai)
// //g,
// dienThoai.gia = "750USD"
// console.log("Giá mới của điện thoại:", dienThoai.gia)
// //h,
// dienThoai.ten = "iPhone 14 promax";
// console.log("Tên mới của điện thoại:", dienThoai.ten)
// console.log('bai tap 3')
// //a,
// // Khởi tạo giá trị cho a và b

// var a = 10;
// var b = 5;
// // Tính tổng
// var tong = a + b
// console.log("Tổng:", tong)
// // Tính hiệu
// var hieu = a - b
// console.log("Hiệu:", hieu)
// // Tính tích
// var tich = a * b
// console.log("Tích:", tich);
// // Tính thương
// var thuong = a / b
// console.log("Thương:", thuong)
// //b,
// // Khởi tạo giá trị cho a và b (có thể thay đổi giá trị tại đây)

// var a = 10
// var b = 5
// // Tính trung bình cộng
// var trungBinhCong = (a + b) / 2
// console.log("Trung bình cộng của", a, "và", b, "là:", trungBinhCong)
// //c,
var x = 3
var y = 4
var z = 6
// Tính giá trị của các biểu thức

var bieuThuc1 = Math.pow(x, 2) + 2 * x + 1
var bieuThuc2 = Math.pow(x, 3) - 3 * x * y - 5 * y + 3 * Math.pow(y, 2)
var bieuThuc3 = Math.pow(x * y, 2) - (2 * Math.pow(x, 2) * y) + (13 * y)
var bieuThuc4 = 4 * Math.pow(x, 3) + 3 * x * y + Math.pow(y, 2) - (2 * Math.pow(x, 2) - 3 * y)
var bieuThuc5 = (5 * Math.pow(x, 2) / 4 * x * y) + Math.pow(y, 2)
var bieuthuc6 = Math.pow(x, 2) - 2 * z * x * y / Math.pow(y, 2) + 5 * x - 2 * Math.pow(y, 2) + 4 * x * Math.pow(z, 3) + Math.pow(z, 3)

console.log("Giá trị của biểu thức 1:", bieuThuc1)
console.log("Giá trị của biểu thức 2:", bieuThuc2)
console.log("Giá trị của biểu thức 3:", bieuThuc3)
console.log("Giá trị của biểu thức 4:", bieuThuc4)
console.log("Giá trị của biểu thức 5:", bieuThuc5)
console.log("Giá trị của biểu thức 6:", bieuthuc6)
// //d,
// var duongKinh = 5
// var banKinh = duongKinh / 2; // Bán kính = Đường kính / 2
// var pi = 3.14 // Giá trị xấp xỉ của pi
// // Tính chu vi và diện tích

// var chuVi = 2 * pi * banKinh
// var dienTich = pi * Math.pow(banKinh, 2)

// console.log("Chu vi của hình tròn là:", chuVi)
// console.log("Diện tích của hình tròn là:", dienTich)
// //e,
// var chieuDai = 15
// var chieuRong = 10
// // Tính chu vi và diện tích

// var chuViHinhChuNhat = 2 * (chieuDai + chieuRong)
// var dienTichHinhChuNhat = chieuDai * chieuRong

// console.log("Chu vi của hình chữ nhật là:", chuViHinhChuNhat)
// console.log("Diện tích của hình chữ nhật là:", dienTichHinhChuNhat)
// //f,
// var quangDuong = 120 // Đơn vị: km
// var thoiGianPhut = 130 // Thời gian trong phút
// // Chuyển thời gian từ phút sang giờ

// var thoiGianGio = thoiGianPhut / 60
// // Tính vận tốc

// var vanToc = quangDuong / thoiGianGio

// console.log("Vận tốc của xe hơi là:", vanToc, "km/h")
// //g,
// var vanToc = 60 // Đơn vị: km/h
// var thoiGianPhut = 150 // Thời gian trong phút
// // Chuyển thời gian từ phút sang giờ

// var thoiGianGio = thoiGianPhut / 60
// // Tính quãng đường có thể di chuyển được

// var quangDuong = vanToc * thoiGianGio

// console.log("Quãng đường xe có thể di chuyển trong 150 phút là:", quangDuong, "km")
// //h,
// var vanToc = 15.2 // Đơn vị: km/h
// var thoiGian = 3 // Đơn vị: giờ
// // Tính quãng đường đi được

// var quangDuong = vanToc * thoiGian

// console.log("Quãng đường của cà nô trong 3 giờ là:", quangDuong, "km")
// //i,
// var vanToc = 42; // Đơn vị: km/h
// // Thời gian di chuyển từ 8 giờ 20 phút đến 11 giờ

// var thoiGianDiChuyen = 2 + (40 / 60); // Tính thời gian di chuyển thành giờ
// // Tính quãng đường đi được

// var quangDuong = vanToc * thoiGianDiChuyen

// console.log("Độ dài của quãng đường AB là:", quangDuong, "km")

// //J
// //chia hinh khối ra 4 phần ta có:
// var dai = 8
// var rong = 5
// var cao = 6
// // tổng thể tích hình khối = dai*rong*cao*4
// var theTich = (dai * rong * cao)*4
// console.log("Tổng Thể tích của khối gỗ là:", theTich)
// //chuyen doi khai bao qua ham so


